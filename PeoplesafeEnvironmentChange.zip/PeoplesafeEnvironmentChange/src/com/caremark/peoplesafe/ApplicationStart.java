package com.caremark.peoplesafe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Import;

import com.caremark.config.DatabaseConfig;

@SpringBootApplication(scanBasePackages = "com.caremark.peoplesafe")
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class })
@Import(DatabaseConfig.class)
public class ApplicationStart {
	
	private static Logger logger = LoggerFactory.getLogger(ApplicationStart.class); 
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("logging.config", "classpath:com/caremark/peoplesafe/config/logback.xml");
		
		SpringApplication.run(ApplicationStart.class, args);
		logger.info("In '{}' of 'main' method.",ApplicationStart.class.getName());
		logger.info("***Application Started***");
	}

}
