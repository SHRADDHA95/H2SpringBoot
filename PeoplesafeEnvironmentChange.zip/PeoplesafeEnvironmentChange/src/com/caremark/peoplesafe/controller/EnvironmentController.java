package com.caremark.peoplesafe.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EnvironmentController {
	
	private static Logger logger = LoggerFactory.getLogger(EnvironmentController.class); 

	@RequestMapping(value = "/")
	public String getEnvironmentChangeHomePage(){
		logger.info("In '{}' of 'getEnvironmentChangeHomePage' method.",this.getClass().getName());
		return "index.html";
	}
}
